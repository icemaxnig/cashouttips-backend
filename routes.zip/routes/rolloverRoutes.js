const express = require("express");
const router = express.Router();

const verifyToken = require("../middleware/verifyToken");
const User = require("../models/User");
const RolloverPlan = require("../models/RolloverPlan");
const RolloverTip = require("../models/RolloverTip");

const {
  createPlan,
  getPublicPlans,
  updatePlan,
  deletePlan,
} = require("../controllers/rolloverPlanController");

const { createRolloverGame } = require("../controllers/rolloverGameController");
const { getTodaysRollover, getGroupedRolloverTips } = require("../controllers/rolloverController");

// ✅ Public: Rollover Plans for frontend (enriched with subscription status)
router.get("/plans", verifyToken, async (req, res) => {
  console.log("🎯 /rollover/plans route hit");
  console.log("🔍 Request user:", req.user);
  
  try {
    if (!req.user || !req.user._id) {
      console.log("❌ User not authenticated");
      return res.status(401).json({ message: "User not authenticated" });
    }

    console.log("✅ User authenticated, fetching plans...");

    // Get all active plans
    const allPlans = await RolloverPlan.find()
      .sort({ createdAt: -1 })
      .lean();

    console.log("📊 Found", allPlans.length, "plans");

    // Calculate which plans to show based on current time
    const now = new Date();
    const fiveMinutesInMs = 5 * 60 * 1000;
    const timeSlot = Math.floor(now.getTime() / fiveMinutesInMs);
    
    // Use timeSlot to determine which plans to show
    const startIndex = (timeSlot % Math.max(1, Math.floor(allPlans.length / 4))) * 4;
    const selectedPlans = allPlans.slice(startIndex, startIndex + 4);

    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const activePlans = user.rolloverPlans || [];
    const enrichedPlans = selectedPlans.map((plan) => {
      const alreadySubscribed = activePlans.some(
        (p) => p.plan?.toString() === plan._id.toString()
      );

      // Calculate fake subscribers for social proof
      const createdAt = new Date(plan.createdAt).getTime();
      const ageHours = Math.floor((Date.now() - createdAt) / (1000 * 60 * 60));
      const fakeSubscribers = plan.fakeStart + (ageHours * plan.growthRatePerHour);

      // Calculate success rate percentage
      const successRate = plan.successRate || 75; // Default to 75% if not set

      return {
        ...plan,
        alreadySubscribed,
        fakeSubscribers: Math.floor(fakeSubscribers),
        cta: {
          text: alreadySubscribed ? "View Details" : "Subscribe Now",
          link: `/rollover-plans/${plan._id}`,
          type: alreadySubscribed ? "view" : "subscribe"
        },
        nextRotation: new Date(Math.ceil(now.getTime() / fiveMinutesInMs) * fiveMinutesInMs),
        metadata: {
          successRate: `${successRate}% Success Rate`,
          subscribers: `${Math.floor(fakeSubscribers)} Active Subscribers`,
          duration: `${plan.duration} Days Access`,
          odds: `${plan.odds}x Daily Odds`
        }
      };
    });

    // Add widget metadata
    const widgetMetadata = {
      totalPlans: allPlans.length,
      currentSlot: timeSlot,
      nextRotation: new Date(Math.ceil(now.getTime() / fiveMinutesInMs) * fiveMinutesInMs),
      timeUntilNext: Math.ceil((Math.ceil(now.getTime() / fiveMinutesInMs) * fiveMinutesInMs - now.getTime()) / 1000),
      showingPlans: `${startIndex + 1}-${startIndex + selectedPlans.length} of ${allPlans.length}`
    };

    res.json({
      plans: enrichedPlans,
      metadata: widgetMetadata
    });
  } catch (err) {
    console.error("❌ Error loading rollover plans:", err);
    res.status(500).json({ message: "Failed to load plans" });
  }
});

// ✅ Admin: Plan management
router.post("/admin/plans", createPlan);
router.put("/admin/plan/:id", updatePlan);
router.delete("/admin/plan/:id", deletePlan);

// ✅ Admin: Upload games
router.post("/admin/game", createRolloverGame);

// ✅ Rollover endpoints
router.get("/today", verifyToken, getTodaysRollover);
router.get("/grouped", getGroupedRolloverTips);

// ✅ My Rollover (user-specific)
router.get("/my", verifyToken, async (req, res) => {
  try {
    const userId = req.user?._id;
    if (!userId) return res.status(401).json({ message: "Unauthorized" });

    const tips = await RolloverTip.find({
      expiresAt: { $gte: new Date() },
    })
      .populate("plan", "name odds duration")
      .sort({ createdAt: -1 });

    const user = await User.findById(userId);
    const activePlans = user?.rolloverPlans || [];

    const myTips = tips.filter(tip =>
      activePlans.some(
        (p) => p.plan?.toString() === tip.plan._id.toString()
      )
    );

    res.json(myTips);
  } catch (err) {
    console.error("❌ Failed to load my rollover tips:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Subscribe to rollover plan
router.post("/subscribe", verifyToken, async (req, res) => {
  const { planId, walletType } = req.body;
  const userId = req.user?._id;

  if (!userId || !planId || !walletType)
    return res.status(400).json({ message: "Missing required fields" });

  try {
    const plan = await RolloverPlan.findById(planId);
    if (!plan) return res.status(404).json({ message: "Plan not found" });

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    const alreadySubscribed = user.rolloverPlans?.some(
      (p) => p.plan?.toString() === plan._id.toString()
    );
    if (alreadySubscribed) {
      return res.status(400).json({ message: "Already subscribed to this plan" });
    }

    const amount = plan.price;

    if (walletType === "bonus") {
      if (user.bonusWallet < amount) {
        return res.status(400).json({ message: "Insufficient bonus wallet balance" });
      }
      user.bonusWallet -= amount;
    } else {
      if (user.mainWallet < amount) {
        return res.status(400).json({ message: "Insufficient main wallet balance" });
      }
      user.mainWallet -= amount;
    }

    user.rolloverPlans = user.rolloverPlans || [];
    user.rolloverPlans.push({
      plan: plan._id,
      startDate: new Date(),
      duration: plan.duration,
    });

    await user.save();

    return res.status(200).json({ message: "Subscription successful" });
  } catch (err) {
    console.error("❌ Error in subscription:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ Get plan by ID
router.get("/plans/:id", verifyToken, async (req, res) => {
  try {
    const plan = await RolloverPlan.findById(req.params.id);
    if (!plan) return res.status(404).json({ message: "Plan not found" });

    const user = await User.findById(req.user.userId);
    const alreadySubscribed = user?.rolloverPlans?.some(
      (p) => p.plan.toString() === plan._id.toString()
    );

    res.json({ ...plan.toObject(), alreadySubscribed });
  } catch (err) {
    console.error("❌ Error fetching plan by ID:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
